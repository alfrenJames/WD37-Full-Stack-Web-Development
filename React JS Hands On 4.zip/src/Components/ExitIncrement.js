const ExitIncrement = (count) => {
    return count+1;
}

export default ExitIncrement;