const LoginIncrement = (count) => {
    return count+1;
}

export default LoginIncrement;