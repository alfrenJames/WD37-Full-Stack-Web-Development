import React from 'react'

const Header = () => {
  return (
    <header className='App-header'>
    <h3>React Hands On 4</h3>
    </header>
  )
}

export default Header