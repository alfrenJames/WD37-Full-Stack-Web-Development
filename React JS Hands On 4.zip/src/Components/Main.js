import React from 'react'
import LoginIncrement from './LoginIncrement';
import ExitIncrement from './ExitIncrement';
import { useState } from 'react';

const Main = () => {
    const [login, setLogin] = useState(0);
    const [exit, setExit] = useState(0);

    const loginCount = () => {
        setLogin(LoginIncrement(login));
    }

    const exitCount = () => {
        setExit(ExitIncrement(exit));
    }

  return (
    <main className='App-Main'>
        <h2>Main Content</h2>
        <div>
            <h1>{login} People Entered!</h1>
            <h1>{exit} People Left!</h1>
        </div>
        <div>
            <button className = 'btn' onClick={loginCount}>LOGIN</button>
            <button className = 'btn' onClick={exitCount}>EXIT</button>
        </div>
    </main>
  )
 
}

export default Main