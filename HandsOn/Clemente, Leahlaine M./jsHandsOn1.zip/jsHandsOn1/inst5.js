let confetti = "Girl";

console.log("Let the gender reveal...");
console.log("Pop the balloon...");
if( confetti == "Blue"){
    console.log("It's a BOY!!!");
}else{
    console.log("It's a GIRL!!!");
}

let gender = (confetti == "Blue") ? "It's a BOY!!!" : "It's a GIRL!!!"
console.log(gender);
