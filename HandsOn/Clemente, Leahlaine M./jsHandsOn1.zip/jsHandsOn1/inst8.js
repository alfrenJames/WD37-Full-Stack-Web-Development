let region = '4.B';

console.log(`Region is ${region}.`);
switch (region) {
    case '1':
        console.log("Ilocos Region");
        break;
    case '2':
        console.log("Cagayan Valley");
        break;
    case '3':
        console.log("Central Luzon");
        break;  
    case '4.A':
        console.log("Calabarzon");
        break; 
    case '4.B':
        console.log("Mimaropa");
        break;
    case '5':
        console.log("Bicol Region");
        break;
    case 'NCR':
        console.log("National Capital Region");
        break;  
    case 'CAR':
        console.log("Cordillera Administrative Region");
        break;  
    default:
        console.log( "Not part of Luzon" );
}