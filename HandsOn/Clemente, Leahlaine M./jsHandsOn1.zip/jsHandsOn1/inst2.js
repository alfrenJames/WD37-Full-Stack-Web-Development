let num1=100;
let num2=24;


console.log("The sum of num1 and num2 is ", num1 + num2 );
console.log("The difference of num1 and num2 is ", num1 - num2 );
console.log("The product of num1 and num2 is ", num1 * num2 );
console.log("The quotient of num1 and num2 is ", num1 / num2 );
console.log("The square of num1 is ", num1**2);
console.log("The remainder of num1 and num2 is ", num1 % num2 );
console.log("If num1 is incremented the result is ", ++num1 );
console.log("If num2 is decremented the result is ", --num2 );