let num=100;
let empName = 'Len';
let isBoolean = true;
let arr = [100,200,300,400];
let nullValue = null;
let sum=0;

console.log("Number: ", num, typeof(num));
console.log("String: ", empName, typeof(empName));
console.log("Bolean: ", isBoolean, typeof(isBoolean));
console.log("Array: ", arr, typeof(arr));
console.log("Null Value: ", nullValue, typeof(nullValue));

