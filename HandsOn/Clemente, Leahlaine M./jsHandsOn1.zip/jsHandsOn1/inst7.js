let grade=65;
let remarks;
let isStudent = true;

if(isStudent == true){
    console.log("Hi, student!");
}

if(grade==100 || grade>=75){
        console.log(`You're grade is ${grade}.`);
        console.log("Congratulations! You are PASSED.");
    }else{
        console.log(`You're grade is ${grade}.`);
        console.log("I am sorry. You are FAILED.");
    }


if(grade==100 || grade>=98){
    remarks = "WITH HIGHEST HONORS";
    console.log(`Kudos! You are awarded as ${remarks}.`);
    } else if(grade>=95){
    remarks = "WITH HIGH HONORS";
    console.log(`Kudos! You are awarded as ${remarks}.`);
    } else if (grade>=90) {
        remarks = "WITH HONORS";
        console.log(`Kudos! You are awarded as ${remarks}.`);
    }else{
        console.log("God bless.");
    }