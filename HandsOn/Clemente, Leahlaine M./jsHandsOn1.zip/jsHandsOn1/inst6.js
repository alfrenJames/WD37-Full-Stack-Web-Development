let arr=[];
let i;

for (let i = 0; i < 5; i++) {
  x = i*50;  
  arr.push(x+100);
  console.log(arr[i]);
}