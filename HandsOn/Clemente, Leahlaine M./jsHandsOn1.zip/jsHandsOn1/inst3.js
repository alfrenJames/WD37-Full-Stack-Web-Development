let num = 3;
let temp = 0;


console.log("The value of  a number is ", num);
console.log("The value of temp is ", temp);

temp = num;
console.log("if a number is equal to temp");
console.log("The value of temp is ", temp);

temp += num;
console.log("Number += temp");
console.log("The value of temp is ", temp);

temp -= num;
console.log("Number -= temp");
console.log("The value of temp is ", temp);

temp *= num;
console.log("Number *= temp");
console.log("The value of temp is ", temp);

temp /= num;
console.log("Number /= temp");
console.log("The value of temp is ", temp);

temp %= num;
console.log("Number %= temp");
console.log("The value of temp is ", temp);

temp **= num;
console.log("Number **= temp");
console.log("The value of temp is ", temp);
