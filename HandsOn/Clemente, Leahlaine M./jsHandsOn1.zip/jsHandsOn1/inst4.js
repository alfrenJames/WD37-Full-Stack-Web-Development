let exam = 90;
let recitation = 74.5;
let isBoolean;

if(exam>=75 && recitation>=75){
    console.log("PASSED.");
}
else{
    console.log("FAILED.");
}

if(exam>=75 || recitation>=75){
    console.log("PASSED.");
}
else{
    console.log("FAILED.");
}

isBoolean = !(exam>=75 && recitation>=75);
console.log(isBoolean);




