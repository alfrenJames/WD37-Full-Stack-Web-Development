function checkAge(name, age){
    let user = {
        name: "Len",
        age: 15
    };


    if (user.age >= 18) {
        user.isLegalAge = true;
    } else{
        user.isLegalAge = false;
    }
      

      console.log(`${user.name} is ${user.age} years old. Is of legal age? ${user.isLegalAge}`);
}
module.exports = checkAge;
