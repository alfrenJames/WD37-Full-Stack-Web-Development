const checkAge = require('./getInfo');

checkAge();