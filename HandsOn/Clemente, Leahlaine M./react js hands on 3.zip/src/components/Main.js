import React from 'react'
import RandomUser from './RandomUser'
import RandomAge from './RandomAge'
import { useState } from 'react';

const Main = () => {

  //randomUser useState
  const[userName,setName] = useState('---');
  const randomName = () => {
    setName(RandomUser());
    };  

  //randomAge useState
  const [userAge,setAge] = useState('---');
  const randomAge = () => {
    setAge(RandomAge());
  };

  const randomNameAge = ()=>{
    randomName();
    randomAge();
  }

  //theme useState
  //to define background color and text color
  const [color, setColor] = useState('lightgray')
  const [textColor, setTextColor] = useState('black')

  const pageThemeDefault = {
      backgroundColor: color,
      color: textColor
  };
  
  //Themes

  const changeToDark = ()=>{
    setColor('black');
    setTextColor('white');
  };

  const changeToLight = ()=>{
    setColor('white');
    setTextColor('black');
  };

  const changeToGreen = ()=>{
    setColor('green');
    setTextColor('white');
  };

  return (
    <main className='App-Main' style={pageThemeDefault}>
      <h1>Main Content</h1>
      {userName}
      <br />
      {userAge}      
      <div>
        <button className='btn my-2 p-3' onClick={randomNameAge} style={{backgroundColor: 'lightgray'}}>Generate Random Name and Age</button> <br /><br />
        <button className='btn my-2 p-3' onClick={changeToLight} style={{backgroundColor: 'lightgray'}}>Light Mode</button> 
        <button className='btn my-2 p-3' onClick={changeToDark} style={{backgroundColor: 'black', color: 'white'}}>Dark Mode</button> 
        <button className='btn my-2 p-3' onClick={changeToGreen} style={{backgroundColor: 'green'}}>Green Mode</button> 
      </div>
    </main>
  )
}

export default Main