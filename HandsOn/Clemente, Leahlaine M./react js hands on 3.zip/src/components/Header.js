import React from 'react'

const Header = () => {
  return (
    <header className='App-header'>
    <h3>React Hands On 3</h3>
    </header>
  )
}

export default Header