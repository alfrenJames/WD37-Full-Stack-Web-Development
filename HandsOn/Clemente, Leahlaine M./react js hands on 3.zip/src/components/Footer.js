import React from 'react'

const Footer = () => {
  return (
    <footer className="App-footer">
      <span>&copy; 2022 Kodego WD37</span>
    </footer>
  )
}

export default Footer