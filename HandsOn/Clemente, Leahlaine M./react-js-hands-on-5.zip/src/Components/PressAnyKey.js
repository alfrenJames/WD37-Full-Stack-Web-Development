const PressAnyKey = (message) => {
    return alert(message);
}

export default PressAnyKey;