import React from 'react'
import CountIncrement from './CountIncrement';
import CountDecrement from './CountDecrement';
import Welcome from './Welcome';
import PressAnyKey from './PressAnyKey';

import { useState } from 'react';
import CurrencyConverter from './CurrencyConverter';

const Main = () => {
    const [ctr, setCtr] = useState(0);


    const increment = () => {
        setCtr(CountIncrement(ctr));
    }

    const decrement = () => {
        setCtr(CountDecrement(ctr));
    }

    const sayWelcome = (message) => {
        Welcome(message);
      }
      const clickMe = (message) => {
        PressAnyKey(message);
      }


  return (
    <main className='App-Main'>
        <h2>Main Content</h2>
        <div>
            <h1>COUNTER: {ctr}</h1>
        </div>
        <div>
            <button className = 'btn' onClick={increment}>INCREMENT</button>
            <button className = 'btn' onClick={decrement}>DECREMENT</button>
        </div>

        <div>
            <button className = "btn" onClick={()=> sayWelcome("Welcome")}>Say Welcome</button>

            {/* <button className='
            btn' onKeyUp={() => clickMe("I was invoked by pressing any key")}>Click on me and Press any key</button> */}

            <input className = "btn " type="submit" value="Click on me and press any in keyboard." onKeyUp={() => clickMe("I was invoked by pressing any keys.")}></input>
        </div>

        <div>
            <CurrencyConverter></CurrencyConverter>
        </div>
    </main>
  )

}

export default Main