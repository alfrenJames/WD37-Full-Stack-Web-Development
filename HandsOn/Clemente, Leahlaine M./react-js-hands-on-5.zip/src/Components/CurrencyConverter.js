import React from 'react'
import { useState } from 'react'

const CurrencyConverter = () => {
    const [val, setName] = useState(0);
    var usd = 0.018;
    const handleSubmit = event =>  {
        setName(event.target.value);
    };
    const logValue = (e) => {
        e.preventDefault();
        //test if val isCaptured
        console.log('val:', val);
        alert("Converting to USD Amount is "+(val*usd));
    };

  return (
    <div>
        <div>
            <br />
            <br />
            Amount:   <input type="number" onChange={handleSubmit}/>
            <br />
            <br />
            Currency:  <textarea value="1 Philippine peso = 54.78 United States Dollar"/>
        </div>
        <button className="btn" onClick={logValue}>Submit</button>
    </div>
  );

}

export default CurrencyConverter