const CountIncrement = (count) => {
    return count+1;
}

export default CountIncrement;