const CountDecrement = (count) => {
    return count-1;
}

export default CountDecrement;