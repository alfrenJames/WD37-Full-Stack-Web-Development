const Welcome = (message) => {
    return alert(message);
}

export default Welcome;