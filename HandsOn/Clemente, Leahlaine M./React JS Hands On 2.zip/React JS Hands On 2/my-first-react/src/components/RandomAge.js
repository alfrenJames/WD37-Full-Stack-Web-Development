
const RandomAge = () => {

    const randomAge = [42,43,16,14,13]
    const index = Math.floor(Math.random() * 5);
    if (randomAge[index] >= 18){
        return 'Age: ' + randomAge[index] + ' is an adult.';
    }else{
        return 'Age: ' + randomAge[index] + ' is too young.';
    }

}

export default RandomAge