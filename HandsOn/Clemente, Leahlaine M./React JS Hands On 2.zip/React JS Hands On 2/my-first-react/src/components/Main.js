import React from 'react'
import RandomUser from './RandomUser'
import RandomAge from './RandomAge'

const Main = () => {
  return (
    <main className='App-Main'>
    <h3>This is Main</h3>
        <RandomUser></RandomUser><br/>
        <RandomAge></RandomAge>
    </main>
  )
}

export default Main