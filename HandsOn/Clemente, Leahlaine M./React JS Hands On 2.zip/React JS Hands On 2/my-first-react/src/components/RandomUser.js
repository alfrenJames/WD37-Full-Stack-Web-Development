
const RandomUser = () => {
  const nameArr = ['Gey', 'Len', 'Laley', 'Caleb', 'Orson']
  const index = Math.floor(Math.random() * 5);
  return nameArr[index];
}

export default RandomUser