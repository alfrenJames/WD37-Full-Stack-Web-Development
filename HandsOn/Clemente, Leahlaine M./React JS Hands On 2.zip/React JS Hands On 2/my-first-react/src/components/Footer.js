import React from 'react'

const Footer = () => {
  return (
    <footer>
    <h3>Footer</h3>
    </footer>
  )
}

export default Footer