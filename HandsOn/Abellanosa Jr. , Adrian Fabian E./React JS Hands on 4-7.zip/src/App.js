import './App.css';
import CountPeople from './component/CountPeople';
import Counter from './component/Counter';
import Currency from './component/CurrencyConvertor';
import Rent from './component/OfficeRent';
import CalculateScore from './component/DisplayCalculateScore';


function App() {
  return (
    <div className="App">
    <h1>Counter</h1>
      <h1>Activity 4</h1>
      <CountPeople/><hr/>
      <h1>Activity 5</h1>
      <Counter/>
      <Currency/><hr/>
      <h1>Activity 6</h1>
      <Rent/><hr/>
      <h1>Activity 7</h1>
      <CalculateScore/>
      </div>
  );
}

export default App;
