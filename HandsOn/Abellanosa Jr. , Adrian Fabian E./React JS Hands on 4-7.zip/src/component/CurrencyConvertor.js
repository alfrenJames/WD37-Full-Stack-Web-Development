import React, {useState} from "react";

const CurrencyConvertor = () => {
    const [val, setName] = useState(0);
    var usd = 0.018;
    const handleSubmit = event =>  {
        setName(event.target.value);
    };
    const logValue = (e) => {
        e.preventDefault();
        //test if val isCaptured
        console.log('val:', val);
        alert("Converting to USD Amount is "+(val*usd));
    };
  return (
    <div className="d-flex flex-column align-items-start">
    <div className="d-flex flex-column container-fluid text-start">
        Amount: <input type="number" onChange={handleSubmit}/>
        Currency: <textarea value="1 Philippine peso = 54.78 United States Dollar"/>
    </div>
        <button className="btn btn-info mt-2 ms-3" onClick={logValue}>Submit</button>
    </div>
  )
}

export default CurrencyConvertor