import React from 'react'
import img1 from './Img/image1.jpg';
import img2 from './Img/image2.jpg';
import img3 from './Img/image3.jpg';
import DisplayDetails from './DisplayDetails';
import '../component/style/style.css';


const OfficeRent=(props) => {
    const rentInfo = [
        {name:"Office Space 1", rentPrice:5000, address:"Manila", scr:img1},
        {name:"Office Space 2", rentPrice:6000, address:"New Delhi", scr:img2},
        {name:"Office Space 3", rentPrice:7000, address:"San Francisco", scr:img3}
    ];
  return(
    <section>
    <h1>Office Space, at Affordable Range</h1>
        {rentInfo.map((e)=>(<DisplayDetails image={e.scr} name={e.name} price={e.rentPrice} add={e.address}/>))}
    </section>
  );
}


export default OfficeRent