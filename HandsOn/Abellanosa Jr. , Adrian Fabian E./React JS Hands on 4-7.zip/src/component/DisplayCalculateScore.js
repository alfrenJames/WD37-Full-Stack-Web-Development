import React from 'react'
import CalculateScore from './CalculateScore'
import { useState } from 'react';

const DisplayCalculateScore = () => {
    const [UserName, setUserName] = useState('User');
    const [School, setSchool] = useState('School');
    const [TotalScore, setTotalScore] = useState(0);
    const [Goal, setGoal] = useState(0);

    const UserNameInput = event => {
        setUserName(event.target.value); 
        console.log('name:',UserName);
    };
    //School
    const SchoolInput = event => {
        setSchool(event.target.value);
        console.log('school:',School);
    };
    //score
    const TotalScoreInput = () => {
        setTotalScore(document.getElementById('score').value); 
       
    };
  
    //goal
    const GoalInput = () => {
        setGoal(document.getElementById('goal').value); 
         
    };
    const logGoal = () => {
        TotalScoreInput();
        GoalInput();
    };
  
  return (
    <div>
     <CalculateScore Name={UserName}
      School={School}
      total={TotalScore}
      goal={Goal}
      />
      <div className="d-flex flex-column align-items-center">
       User Name: <input type="text" onChange={UserNameInput}/>
       School: <input type="text" onChange={SchoolInput}/>
       Total Score: <input type="number" id="score"/>
       goal: <input type="number" id="goal"/>
       <button className="mt-3" type="submit" onClick={logGoal}>Calculate</button>
       </div>
    </div>
  )
}

export default DisplayCalculateScore