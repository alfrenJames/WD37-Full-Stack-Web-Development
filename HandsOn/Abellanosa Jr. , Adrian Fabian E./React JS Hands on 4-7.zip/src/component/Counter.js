import React from 'react'
import { useState } from 'react';

const Counter = () => {
    const [counterValue, setCounterValue] = useState(0);
    const increment = () => {
        setCounterValue(counterValue + 1); 
        return counterValue;
    };

    const decrement = () => {
        setCounterValue(counterValue - 1); 
        return counterValue;
    };
    const sayWelcome = () => {
        alert('Welcome')
    };
    const clickMe = () => {
        alert('welcome')
    };
  return (
    <div className="container-fluid d-flex flex-column text-start">
        Counter: {counterValue}
        <button className="btn btn-info me-3 h3 col-3" onClick={increment}>
            Increment
        </button>
        <button className="btn btn-info me-3 h3 col-3" onClick={decrement}>
            Decrement
        </button>
        <button className="btn btn-info me-3 h3 col-3" onClick={() => sayWelcome("welcome")}>
            Say Welcome
        </button>
        <input className='btn btn-info me-3 h3 col-3' type="submit"
         value="Click on me and Press Any in keyboard" onKeyUp={() => clickMe("I was Invoked by pressing any keys")}>
        </input>
    </div>
  )
}

export default Counter