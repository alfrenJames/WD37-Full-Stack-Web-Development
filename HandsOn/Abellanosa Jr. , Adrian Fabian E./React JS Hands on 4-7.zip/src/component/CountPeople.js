import React from 'react'
import { useState } from 'react';

const CountPeople = () => {
    const [LoginCount, setLoginCount] = useState(0);
    const [ExitCount, setExitIncrement] = useState(0);
    const LoginIncrement = () => {
        setLoginCount(LoginCount + 1); 
        return LoginCount;
    };

    const ExitIncrement = () => {
        setExitIncrement(ExitCount + 1); 
        return ExitCount;
    };
  return (
    <div>
    <button className='btn btn-primary m-2 border border-2' onClick={LoginIncrement}>Login</button>
    <br/>
    <p> {LoginCount} People Entered!!! </p> 
    <br/>
    <button className='btn btn-success m-2' onClick={ExitIncrement}>Exit</button>
    <br/>
    <p> {ExitCount} People Left!!! </p>
    </div>
  )
}

export default CountPeople