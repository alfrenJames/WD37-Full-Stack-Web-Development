export default function CourseDetails(){
    return (
        <section className="bg-dark text-white text-center mx-5 my-5 border rounded">
            <div className="display-5 mb-2">Course Details</div>
            <div className="display-6 mb-5">Title: Vue</div>
            <div className="bg-white text-dark container mb-5">
            <p className="text-muted">4/5/2022</p>
            <div className="display-6 mb-5">Title:React</div>
            <p className="text-muted">4/5/2022</p>
            </div>
        </section>
    );
}