export default function BlogDetails(){
    return (
        <section className="bg-dark text-white text-center mx-5 my-5 border rounded">
            <div className="display-5 mb-2">Blog Details</div>
            <div className="display-6 mb-5">Title: React Learning</div>
            <div className="bg-white text-dark container mb-5">
            <p className="text-muted bold">Stephen Biz</p>
            <p className="text-muted">Welcome to learning Reach</p>
            <div className="display-6 mb-5">Title:Installation</div>
            <p className="text-muted bold">Schewzdenier</p>
            <p className="text-muted">You can install React from npm</p>
          
            </div>
        </section>
    );
}
