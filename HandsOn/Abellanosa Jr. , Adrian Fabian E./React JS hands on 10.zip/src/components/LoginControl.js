import { LoginButton, LogoutButton, Greeting} from "./Greetings";
import { useState } from "react";

const LoginControl = () => {
    const [userLoggedIn, setUserLoggedIn] = useState
    (false);
    const isLoggedIn = userLoggedIn;

    let button = null;
    if (isLoggedIn) {
        button = <LogoutButton onClick={() =>
        setUserLoggedIn(false)}/>;
    } else {
        button = <LoginButton onClick = {() => setUserLoggedIn (true)}/>;
    }
    return (
        <main>
            <Greeting title = {"HELLO"} isLoggedIn=
            {isLoggedIn}/>
            {button}
        </main>
    );
}

export default LoginControl;