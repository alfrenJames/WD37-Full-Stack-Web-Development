export default function LoggedInPage(){
    return (
        <section className="bg-dark text-white text-center mx-5 my-5 border rounded">
            <div className="display-5 mb-2">User Page!</div>
            <div className="display-6 mb-5">Welcome to Ticket Booking App</div>
            <div className="bg-white text-dark container mb-5">
                <p className="display-6">Flight Details</p>
                <ul>
                    <li>FlightNumber:1001</li>
                    <li>SeatNumber: 25-B</li>
                    <li>ReferrenceNumber: NAI-123450-xxxx</li>
                </ul>
                <p className="text-muted">Last updated 3 mins ago</p>
                <img src="../src/img/plane.jpg" alt="Plane"></img>
            </div>
        </section>
    );
}