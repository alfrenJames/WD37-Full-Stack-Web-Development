function handleSubmit(){
    alert(
        "Thank You, " +inputName+ "\nYour Complaint Was Submitted." + "\nTransaction ID is: 0"+transactionID
    );
}

function getRandomNumberBetween(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); // The maximum if exclusive and the minimum is inclusive
}

function getName(e){
    setInputName(e.target.value)
}

function generateTransID(){
    const randomNumber = getRandomnumberBetwee(1,100);
    setTransactionId(Date.now() + randomNumber);
}

<div className="container mt-4 bg-light text-dark w-25 d-flex justify-content-center">
    <form 
        onSubmit={handleSubmit}
        className="text-start col-lg-auto g-3 align-items-center"
    >
        <label>
            <div className="mb-3">
                <div className="display-6 mb-3">Name:
            </div>
                <input className="form-control mb-5" type="text" placeholder="enter your name here" id="name" onChange={getName}/>
            </div>
            
            <div className="mb-3">
                <div className="dispaly-6 mb-3">Complaint:</div>
                <textarea className="form control mb-5" placeholde="enter your concern here"></textarea>
            </div>
            <input onclick={generateTransID}
            type="submit" value="Submit" className="btn btn-primary"/>
        </label>
    </form>
</div>