// import LoginControl from './components/LoginControl';
import ShowControl from './components/Activity 10/ShowControl';
import './App.css';

function App() {
  return (
    <div className="App">
    {/* <LoginControl/> */}
    <ShowControl/>
    </div> 
  );
}

export default App;
