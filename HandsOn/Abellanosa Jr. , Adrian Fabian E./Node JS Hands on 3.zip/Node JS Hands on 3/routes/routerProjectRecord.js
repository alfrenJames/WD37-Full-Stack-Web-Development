const express = require('express');
const data = require('../fakeDb/data');
projectRecord = express.Router();


//get data
projectRecord.get('/records', (req, res) => {
    res.render('records', {data: data});
    console.log(data);
});

//get by id
projectRecord.get('/records/:id', (req, res) =>{
    let check = data.find((items) => {
        return parseInt(items.id) === parseInt(req.params.id)
    });
    //verify if id exist
    if(check){
        res.render('view', {records: check})
    }else{
        res.status(404).render('ID does not exist');
        console.log('record not found');
    }
});


//update record by id
projectRecord.get('/update/:id', (req, res) => {
    let check = data.find((item) => {
        return parseInt(item.id) === parseInt(req.params.id)
    });
    if (check) {
        res.render('edit', { records: check });
    } else {
        res.status(404).send('ID not found!');
    }
});

projectRecord.put('/update/:id', (req, res) => {
    let id = +req.params.id;
    let body = req.body;
    let index = data.findIndex((df) => parseInt(df.id) === parseInt(id));

    if (index >= 0) {
        let updateData = { id: id, ...body };
        data[index] = updateData;
        res.redirect('/records');
    } else {
        res.status(404).send('Id does not exist');
    }

});
   

//delete record by ID
projectRecord.delete('/:id', (req, res) => {
    let id = +req.params.id;
    let index = data.findIndex((df) => parseInt(df.id) === parseInt(id));
    if (index >= 0) {
        data.splice(index, 1);
        res.redirect('/records');
    } else {
        res.status(404).send('ID not found');
    }
    console.log(index);
});


module.exports = projectRecord;
