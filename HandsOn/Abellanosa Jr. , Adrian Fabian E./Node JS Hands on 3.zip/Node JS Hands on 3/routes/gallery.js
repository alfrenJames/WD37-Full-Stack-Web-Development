const express = require('express');
const routerGallery = express.Router();

routerGallery.get('/gallery', (req, res) => {
    res.render('gallery');
});

module.exports = routerGallery;