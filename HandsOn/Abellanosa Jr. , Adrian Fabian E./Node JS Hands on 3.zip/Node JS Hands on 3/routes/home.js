const express = require('express');
const homeRouter= express();

homeRouter.get('/', (req, res)=>{
    res.render('home');
    res.render('home', {test:'EJS is working and Waving 🙌'});
});

module.exports = homeRouter;