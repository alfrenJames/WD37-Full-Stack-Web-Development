const express = require('express');
const data = require('../fakeDb/data');
const addNewRecord= express();

addNewRecord.get('/addNewRecord', (req, res)=>{
    res.render('addNewRecord');
});

//add new record
addNewRecord.post('', (req, res) => {
    let body = req.body;
    data.push(body);
    console.log(data);
    res.redirect('/records');
});

module.exports = addNewRecord;