const express = require('express');
const app = express();
const getProjectRecord = require('./routes/routerProjectRecord');
const homeRouter = require('./routes/home');
const addNewRecord = require('./routes/addNewRecord');
const routerGallery = require('./routes/gallery');
const methodOverride = require('method-override');

//static File
app.use(express.static('public'));
app.use('/css', express.static(__dirname+'public/css'));

//middleware
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(methodOverride('_method'));


//routes
app.use('/', homeRouter);
app.use('/', getProjectRecord);
app.use('/', addNewRecord);
app.use('/', routerGallery);

//setup views
app.set('views', './views');
app.set('view engine', 'ejs');

//server conn check
let port = 80;
app.listen(port,()=>{
    console.log(`connection successfull with port: ${port}`);
});