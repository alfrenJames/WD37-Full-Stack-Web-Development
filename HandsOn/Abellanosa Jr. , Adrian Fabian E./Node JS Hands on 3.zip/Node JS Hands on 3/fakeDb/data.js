let data =[
    { id: 1, title: 'Create a project',  order: 1, completed: true, author: 'Diego Laura', linkBookimage: 'https://books.google.com/books/publisher/content/images/frontcover/sVxqDwAAQBAJ?fife=w256-h256'  },
    { id: 2, title: 'Take a cofféé',     order: 2, completed: true, author: 'Laong-Laan', linkBookimage: 'https://books.google.com/books/publisher/content/images/frontcover/nkYtEAAAQBAJ?fife=w256-h256'},
    { id: 3, title: 'Write new article', order: 3, completed: true, author: 'Agap-ito Bagumbayan', linkBookimage: 'https://books.google.com/books/publisher/content/images/frontcover/zK_CDwAAQBAJ?fife=w256-h256' },
    { id: 4, title: 'Walk toward home', order: 4, completed: false, author: 'Taga-Ilog', linkBookimage: 'https://books.google.com/books/publisher/content/images/frontcover/UXyGEAAAQBAJ?fife=w256-h256'},
    { id: 5, title: 'Have some dinner', order: 5, completed: false, author: 'Dimas-Ilaw', linkBookimage: 'https://books.google.com/books/publisher/content/images/frontcover/sGyrCQAAQBAJ?fife=w256-h256' },
    { id: 6, title: 'Secret Project', order: 5, completed: true, author: 'Secret-Man', linkBookimage: 'https://books.google.com/books/publisher/content/images/frontcover/uomkEAAAQBAJ?fife=w256-h256' },
    { id: 7, title: 'Transformer', order: 5, completed: true, author: 'Op-Prime', linkBookimage: 'https://books.google.com/books/content/images/frontcover/u8QVVR8OTosC?fife=w256-h256' },
    { id: 8, title: 'Tick Tock', order: 5, completed: true, author: 'Fern-Michael', linkBookimage: 'https://books.google.com/books/publisher/content/images/frontcover/9y1sEAAAQBAJ?fife=w256-h256' },
    { id: 9, title: 'Life as a Vapor', order: 5, completed: true, author: 'John-Piper', linkBookimage: 'https://books.google.com/books/content/images/frontcover/j9njH4ihyHAC?fife=w256-h256' },
    { id: 10, title: 'Faith', order: 5, completed: true, author: 'David', linkBookimage: 'https://books.google.com/books/content/images/frontcover/0ya91AZr524C?fife=w256-h256' }
];


module.exports = data;