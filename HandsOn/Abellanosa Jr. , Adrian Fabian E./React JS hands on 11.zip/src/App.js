// import LoginControl from './components/LoginControl';
// import ShowControl from './components/Activity 10/ShowControl';
import ComplaintRegister from './components/Activity 11/ComplaintRegister';
import './App.css';

function App() {
  return (
    <div className="App">
    {/* <LoginControl/> */}
    {/* <ShowControl/> */}
    <ComplaintRegister/>
    </div> 
  );
}

export default App;
