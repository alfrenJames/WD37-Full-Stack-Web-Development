export default function LoggedOutPage(){
    return(
        <section className="bg-dark text-white text-center mx-5 my-5 border rounded">
            <div className="display-5">Guest Page!</div>
            <div className="display-6">Welcome to Ticket Booking App</div>
        </section>
    );
}