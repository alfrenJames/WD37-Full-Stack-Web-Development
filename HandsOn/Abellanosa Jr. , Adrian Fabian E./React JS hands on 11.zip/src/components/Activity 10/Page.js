import BlogDetails from '../Activity 10/BlogDetails';
import BookDetails from '../Activity 10/BookDetails';
import CourseDetails from '../Activity 10/CourseDetails';

const HomePage = (props) => {
    const isShow = props.isShow;
    if (isShow){
        return (
            <div className = "d-flex flex-column justify-content-start">
            </div>
            )
    };
        return (
            <div className = "d-flex flex-row flex-nowrap">
               <BookDetails />
               <BlogDetails />
               <CourseDetails />
            </div>
        )
};

const ShowButton = (props) => {
    return (
        <div className="container mt-2 d-flex justify-content-center">
            <button className="btn btn-primary" onClick={props.onClick}>
                Hide
            </button>
        </div> 
    );
};

const HideButton = (props) => {
    return (
         <div className="container mt-2 d-flex justify-content-center">
            <button className="btn btn-primary" onClick={props.onClick}>
                Show
            </button>
        </div> 
    );
};

export {ShowButton, HideButton, HomePage};