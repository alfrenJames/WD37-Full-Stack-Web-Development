import { ShowButton, HideButton, HomePage} from "./Page";
import { useState } from "react";

const ShowControl = () => {
    const [Show, setShow] = useState
    (false);
    const isShow = Show;

    let button = null;
    if (isShow) {
        button = <HideButton onClick={() =>
        setShow(false)}/>;
    } else {
        button = <ShowButton onClick = {() => 
        setShow (true)}/>;
    }
    
    return (
        <main>
            <HomePage title = {"HELLO"} isShow=
            {isShow}/>
            {button}
        </main>
    )
}

export default ShowControl;