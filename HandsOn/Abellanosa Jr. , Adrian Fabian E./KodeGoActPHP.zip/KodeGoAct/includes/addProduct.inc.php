<?php
    $product = new productRecord;
    $product -> set_product_record("Lebron James Basketball Shoes for men", 400, "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/cc5945aa-2d48-4441-b357-6edc7756718c/lebron-xx-se-older-basketball-shoes-rpB84m.png", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
    $product -> set_product_record("Men Basketall Shoes Sneaker High Cut Air", 400, "https://static.nike.com/a/images/t_PDP_1280_v1/f_auto,q_auto:eco/67c44eb7-7d3f-447d-8e79-5dc7f586288c/lebron-witness-7-ep-basketball-shoes-FKPXCg.png", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
    $product -> set_product_record("Korean Vulcanized Muffin Jogging rubber Shoes", 400, "https://underarmour.scene7.com/is/image/Underarmour/3025093-001_DEFAULT?rp=standard-30pad|pdpZoomDesktop&scl=0.50&fmt=jpg&qlt=85&resMode=sharp2&cache=on,on&bgc=f0f0f0&wid=1836&hei=1950&size=850,850", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
    $product -> set_product_record("New Sneaker Men Breathable Casual running Shoes", 400, "https://underarmour.scene7.com/is/image/Underarmour/3024263-102_DEFAULT?rp=standard-30pad|pdpZoomDesktop&scl=0.50&fmt=jpg&qlt=85&resMode=sharp2&cache=on,on&bgc=f0f0f0&wid=1836&hei=1950&size=850,850", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
    $product -> set_product_record("Lebron James Basketball Shoes for men", 400, "https://static.nike.com/a/images/t_PDP_1280_v1/f_auto,q_auto:eco/a804053a-0ee2-47fa-a082-0494deb6f00c/precision-6-basketball-shoes-h5907m.png", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
    $product -> set_product_record("Lebron James Basketball Shoes for men", 400, "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/cc5945aa-2d48-4441-b357-6edc7756718c/lebron-xx-se-older-basketball-shoes-rpB84m.png", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
    $product -> set_product_record("Lebron James Basketball Shoes for men", 400, "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/cc5945aa-2d48-4441-b357-6edc7756718c/lebron-xx-se-older-basketball-shoes-rpB84m.png", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
    $product -> set_product_record("Lebron James Basketball Shoes for men", 400, "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/cc5945aa-2d48-4441-b357-6edc7756718c/lebron-xx-se-older-basketball-shoes-rpB84m.png", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
    $product -> set_product_record("Lebron James Basketball Shoes for men", 400, "https://static.nike.com/a/images/c_limit,w_592,f_auto/t_product_v1/cc5945aa-2d48-4441-b357-6edc7756718c/lebron-xx-se-older-basketball-shoes-rpB84m.png", "10.1k", "Pasay Metro Manila", "100%");
    $product -> get_product_record();
?>
