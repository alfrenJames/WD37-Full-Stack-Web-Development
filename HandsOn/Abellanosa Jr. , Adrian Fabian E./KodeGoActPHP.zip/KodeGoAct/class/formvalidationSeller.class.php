<?php
    // define variables and set to empty values
    $name_err = $location_err = $contactNumber_err = $photo_err ="";
    $name = $location = $contactNumber = $photo ="";
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
        }
  
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = test_input($_POST["name"]);
        $location = test_input($_POST["location"]);
        $contactNumber = test_input($_POST["contact"]);
        $photo = test_input($_POST["photo"]);


        // productName (Required min of 5 char but less than 100 char) amd require filled
        if (empty($_POST["name"])) {
            $name_err = "Required Field";
        } else if 
             (strlen($name) < 5 || strlen($name) > 100){
                falert("name should be more than 5 char and less than 100"); 
             }
        //price(Requiered must be int) and required filled.
        if (empty($_POST["contact"])) {
            $contactNumber_err = "Required Field";    
    }    
    }
    function falert($msg){
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
?>