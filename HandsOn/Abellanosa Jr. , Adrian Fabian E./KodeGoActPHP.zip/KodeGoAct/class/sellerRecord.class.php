<?php

class sellerRecord{
    public $Name, $ContactNumber, $Location, $Photo;
    public $dir = "img/";
    const BR = "</BR>";

    function set_seller_record($Name, $ContactNumber,$Location, $Photo){
        $this-> Name = $Name;
        $this-> Location = $Location;
        $this-> ContactNumber = $ContactNumber;
        $this-> Photo = $Photo;
    }

    function get_seller_record(){
        echo "<div class='card me-2 my-2' style='width: 18rem;'>";
        echo "<img src='{$this->Photo}' class='card-img-top' alt='...'>";
        echo "<div class='card-body mb-auto'>";
        echo "<p class='card-text'>{$this-> Name}</p>";
        echo "<p>Contact Number:{$this-> ContactNumber}</p>";
        echo "<p class='card-text'>Location:{$this-> Location}</p>";
        echo "</div>";
        echo "</div>";
    }
}

?>