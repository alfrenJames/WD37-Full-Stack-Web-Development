import Main from './component/MainDisplay';
import './App.css';

function App() {
  return (
    <div className="App">
    <Main/>
    </div>
  );
}

export default App;
