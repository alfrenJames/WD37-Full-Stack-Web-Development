import React from 'react'
import players from "./Players"
import ListOfPlayers from "./ListOfPlayers"
import ListOfPinoyPlayers from "./ListOfPinoyPlayers"
import PlayerScoreBelow70 from "./PlayerScoreBelow70"
import { useState } from 'react';


function OddPlayer ([first, ,third, ,fifth]){
    return(
        <div>
            <li>1st: {first.name} {first.score}</li>
            <li>3rd: {third.name} {third.score}</li>
            <li>5th: {fifth.name} {fifth.score}</li>
        </div>
    )
}
function EvenPlayers ([,second, ,fourth, ,sixth]){
    return(
        <div>
            <li>2nd: {second.name} {second.score}</li>
            <li>4th: {fourth.name} {fourth.score}</li>
            <li>6th: {sixth.name} {sixth.score}</li>
        </div>
    )
}

//Destructuring
let a,b,c,d,e,rest;
[a,b,c,d,e,...rest] = players;

const FilipinoTeam = rest;

const GetOddFilipinoPlayer = ['1st Player', '2nd Player', ' 5thPlayer'];
const GetEvenFilipinoPlayer = ['6th Player', ' 7thPlayer', '8th Player'];
const FilipinoPlayers = [...GetOddFilipinoPlayer,...GetEvenFilipinoPlayer]

function MainDisplay(){
    const[flag, setFlag] = useState(true);
    if (flag === true) {
        return (
            <div>
                <button onClick={() => setFlag(false)}>Flag: True</button>
                <h1>List Of Players</h1>
                <ListOfPlayers players={players}/>
                <h1>List of Player Below 70</h1>
                <PlayerScoreBelow70 players={players}/>
            </div>
        );
    } else {
        return (
            <div>
                <button onClick={()=> setFlag(true)}>Flag: False</button>
                <h1>Filipino Team</h1>
                <h1>Odd Players</h1>
                {OddPlayer(FilipinoTeam)}
                <h1>Even Players</h1>
                {EvenPlayers(FilipinoTeam)}
                <h1>List of Filipino Player Merge</h1>
                <ListOfPinoyPlayers players={FilipinoPlayers}/>
            </div>
        );
    }
}
export default MainDisplay;