import players from "./Players"

const PlayerScoreBelow70 = ({players}) => {
    var playersBelow70 = players.filter(player => player.score <= 70);
    return(
        playersBelow70.map((player) =>
            <div>
                <li>Player.{player.name} <span>{player.score}</span></li>
            </div>
            )
    );
}
export default PlayerScoreBelow70