const players = [
    {name: "Maharlika", score : 50}, 
    {name: "Kidlat", score : 70}, 
    {name: "Shawn", score : 40}, 
    {name: "Adbul", score : 61}, 
    {name: "Dakila", score : 61}, 
    {name: "Urduja", score : 50}, 
    {name: "Makisig", score : 39}, 
    {name: "Malakas", score : 84}, 
    {name: "Alab", score : 64}, 
    {name: "Amihan", score : 75}, 
    {name: "Datu", score : 80}, 
];

export default players;