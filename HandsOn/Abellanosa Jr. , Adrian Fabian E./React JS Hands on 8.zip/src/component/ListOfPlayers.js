import players from "./Players"

const ListOfPlayers = ({players}) => {
    return(
        players.map((item) =>
            <div>
                <li>Player.{item.name} <span>{item.score}</span></li>
            </div>
        )
    );
}
export default ListOfPlayers

