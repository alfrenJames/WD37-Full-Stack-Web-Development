const getPersonInfo = require('./getInfo');


console.log(getPersonInfo('Adrian', 15));