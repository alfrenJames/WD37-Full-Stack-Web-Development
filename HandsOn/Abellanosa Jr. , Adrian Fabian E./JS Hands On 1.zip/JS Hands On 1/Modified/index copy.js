const checkAge = require('./checkAge');
// const Age = require('./checkAge');
// Age();