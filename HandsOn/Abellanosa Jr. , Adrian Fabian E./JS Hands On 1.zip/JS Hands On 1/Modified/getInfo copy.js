const Age = require('./checkAge');

function Person(vName, vAge){
 Age(vName, vAge);
 let personInfo = {name:vName, age:vAge}
 return personInfo;
 
}
module.exports= Person;

console.log(Person('Adrian', 15));