function getAge(name, age){
    let isLegalAge = true;
 

    if (age < 18) {
        isLegalAge = false;
    }else{
        isLegalAge = true;
    }

    console.log(isLegalAge);
}
module.exports = getAge;

