function getAge(personProfile){

    if (personProfile.age < 18) {
        personProfile.isLegalAge = false;
    }else{
        personProfile.isLegalAge = true;
    }
    return personProfile;
}
module.exports = getAge;