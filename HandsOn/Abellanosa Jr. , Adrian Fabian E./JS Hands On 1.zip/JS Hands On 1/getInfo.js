const checkAge = require('./checkAge');
var personProfile={ }

function getPersonInfo(pullName, pullAge,){
  personProfile = { name: pullName, 
                    age: pullAge
};
 return(checkAge(personProfile));
}

module.exports = getPersonInfo;
