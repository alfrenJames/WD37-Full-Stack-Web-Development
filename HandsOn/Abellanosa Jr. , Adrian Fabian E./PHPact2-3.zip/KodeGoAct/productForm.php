<!DOCTYPE HTML>  
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<link rel="stylesheet" href="./css/style.css">
</head>
<body>  
<?php
    include "./partials/header.php"
    ?>

    <?php
    include "./class/formvalidationProduct.class.php"
    ?>

    <div class = "divf mt-4 p-2">
        <h2>PHP Form Validation Without Database</h2>
        <form method="post" class="formf" >
            Product Name: <input type="text" name="productName">
             <?php echo "<span class='_error'>{$product_err}</span>"; ?>
            <br><br>
            Price: <input type="text" name="Price">
           <?php echo" <span class='_error'>{$price_err}</span>";?>
            <br><br>
            Discount: <input type="text" name="Discount">
             <?php echo "<span class='_error'>$discount_err</span>";?>
            <br><br>
            Number Of Sold: <input type="text" name="NumberOfSold">
             <?php echo"<span class='_error'>{$numberSold_err}</span>";?>
            <br><br>
            Seller Location: <input type="text" name="SellerLocation">
             <?php echo "<span class='_error'>{$sellerLocation_err}</span>";?>
             <br><br>
             <input type="submit" name="submit" value="Submit"/>  
        </form>
        <form method="POST" action="upload.php" enctype="multipart/form-data">
        <?php
           session_start();
           if (isset($_SESSION['message']) && $_SESSION['message'])
             {
                printf('<b>%s</b>', $_SESSION['message']);
                unset($_SESSION['message']);
            }
        ?>
            Upload a File:<br><input type="file" name="uploadedFile" />
            <input type="submit" name="uploadBtn" value="Upload" />
        </form>
      
    </div>
    <?php
    echo "<div class='container text-center'>";
    echo "<h2>Your Input:</h2>";
    echo $pName;
    echo "<br>";
    echo $price;
    echo "<br>";
    echo $discount;
    echo "<br>";
    echo $numberOfSold;
    echo "<br>";
    echo $sellerLocation;
    echo "</div>";
    echo $productImage;
    echo "</div>";
    ?>

<?php
        include "./partials/footer.php"
    ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>
Footer
© 2023 GitHub, Inc.
Footer navigation
Terms
Privacy
Security
Status
Docs
Contact GitHub
Pricing
API
Training
Blog
About
