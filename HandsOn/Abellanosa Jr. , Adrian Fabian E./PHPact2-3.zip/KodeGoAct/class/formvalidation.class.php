<?php
    // define variables and set to empty values
    $name_err = $email_err = $password_err = $date_err = "";
    $lname = $fname = $email = $confirm = $password = $birth_date = "";
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
        }
  
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $passwordSize = 6;
        $lname = test_input($_POST["last_name"]);
        $fname = test_input($_POST["first_name"]);
        $email = test_input($_POST["email"]);
        $confirm = test_input($_POST["confirm"]);
        $password = test_input($_POST["password"]);
        $birth_date = test_input($_POST["birth_date"]);

        if (empty($_POST["last_name"]) || empty($_POST["first_name"])) {
            $name_err = "Required Field";
        } else {
            // check if name only contains letters and whitespace
            if (!preg_match("/^[a-zA-Z-' ]*$/",$lname) || !preg_match("/^[a-zA-Z-' ]*$/",$fname)) {
            $name_err = "Only letters are Allowed";
            }
        }
        if (empty($_POST["email"])) {
            $email_err = "Email is required";
        } else {
            // check if e-mail address is well-formed
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $email_err = "Invalid email format";
            }
        }
        if (empty($_POST["password"])) {
            $password_err = "Password is Required";
        }else{
            if($password != $confirm){
                $password_err = "Password not Match";
            }else if(strlen($password) < $passwordSize){
                $password_err = "Weak Password Min. of 6 character";
            }
        }
        if (empty($_POST["birth_date"])){
            $date_err =  "Date is Required";
        }else{
            $dataDate = explode("-", $birth_date);
            $year = date("Y") - $dataDate[0];
            echo $year;
            if($birth_date > date("Y-m-d") || $year > 151){
                $date_err = "Invalid Date";
            }
        }
    
    }    
?>