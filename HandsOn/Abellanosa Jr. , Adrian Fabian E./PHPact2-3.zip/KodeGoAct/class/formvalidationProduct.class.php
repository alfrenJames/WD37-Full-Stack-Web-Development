<?php
    // define variables and set to empty values
    $product_err = $price_err = $discount_err = $numberSold_err = $sellerLocation_err = $productImage_err ="";
    $lname = $pName = $price = $discount = $numberOfSold = $sellerLocation = $productImage = "";
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
        }
  
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $pName = test_input($_POST["productName"]);
        $price = test_input($_POST["Price"]);
        $discount = test_input($_POST["Discount"]);
        $numberOfSold = test_input($_POST["NumberOfSold"]);
        $sellerLocation = test_input($_POST["SellerLocation"]);


        // productName (Required min of 5 char but less than 100 char) amd require filled
        if (empty($_POST["productName"])) {
            $product_err = "Required Field";
        } else if 
             (strlen($pName) < 5 || strlen($pName) > 100){
                falert("name should be more than 5 char and less than 100"); 
             }
        //price(Requiered must be int) and required filled.
        if (empty($_POST["Price"])) {
            $price_err = "Required Field";
        }
        else if  (!is_numeric($price)){
            falert('Price must be int');
        }

        //discount(Not Required must be int)
       if  (!is_numeric($discount)){
            falert('Discount must be int');
        }

        //numberOfSold(Required must be int)
        if (empty($_POST["NumberOfSold"])) {
            $numberSold_err = "Required Field";
        }
        else if  (!is_numeric($numberOfSold)){
            falert('Number Of Sold Items must be int');
        }

        //sellerLocation(Requiered min of 10 char)
        if (empty($_POST["SellerLocation"])) {
            $sellerLocation_err = "Required Field";
        }
        else if  (strlen($sellerLocation) < 10){
            falert('Location must be atleast 10 characters');
        }
    }    

    function falert($msg){
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
?>