<?php

class productRecord{
    public $itemDescription, $price, $itemImage, $numberOfSold, $sellersLocation, $discount;
    public $dir = "img/";
    const BR = "</BR>";

    function set_product_record($itemDescription, $price, $itemImage, $numberOfSold, $sellersLocation, $discount){
        $this-> itemDescription = $itemDescription;
        $this-> price = $price;
        $this-> itemImage = $itemImage;
        $this-> numberOfSold = $numberOfSold;
        $this-> sellersLocation = $sellersLocation;
        $this-> discount = $discount;
    }

    function get_product_record(){
        echo "<div class='card me-2 my-2' style='width: 18rem;'>";
        echo "<img src='{$this->itemImage}' class='card-img-top' alt='...'>";
        echo "<div class='card-body mb-auto'>";
        echo "<p class='card-text'>{$this-> itemDescription}</p>";
        echo "<p class='card-text'>{$this-> discount}</p>";
        echo "<p>Price:{$this-> price}</p>";
        echo "<p>⭐⭐⭐⭐⭐sold:{$this-> numberOfSold}</p>";
        echo "<p class='card-text'>{$this-> sellersLocation}</p>";
        echo "</div>";
        echo "</div>";
    }
}

?>