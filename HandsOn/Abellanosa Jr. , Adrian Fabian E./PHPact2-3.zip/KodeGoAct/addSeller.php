

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
        

    <?php
    include "./partials/header.php";
    include "./class/sellersInfo.class.php";
    ?>

<div class = "divf mt-4 p-2">
        <h2>Seller</h2>
        <form method="POST" class="formf" >
            Name: <input type="text" name="name">
             <?php echo "<span class='_error'>{$name_err}</span>"; ?>
            <br><br>
            Location: <input type="text" name="location">
           <?php echo" <span class='_error'>{$location_err}</span>";?>
            <br><br>
            Contact #: <input type="number" name="contact">
             <?php echo "<span class='_error'>$contactNumber_err</span>";?>
            <br><br>
            Photo: <input type="text" name="photo">
             <?php echo"<span class='_error'>{$photo_err}</span>";?>
            <br><br>
            <input type="submit" name="submit" value="Submit"/>  
        </form>
        <form method="POST" action="upload.php" enctype="multipart/form-data">
        <?php
           session_start();
           if (isset($_SESSION['message']) && $_SESSION['message'])
             {
                printf('<b>%s</b>', $_SESSION['message']);
                unset($_SESSION['message']);
            }
        ?>
            Upload a File:<br><input type="file" name="uploadedFile" />
            <input type="submit" name="uploadBtn" value="Upload" />
        </form>
      
    <?php
        echo "<div class='container text-center'>";
        echo "<h2>Your Input:</h2>";
        echo $name;
        echo "<br>";
        echo $location;
        echo "<br>";
        echo $contactNumber;
        echo "<br>";
        echo $Photo;
        echo "</div>"
    ?>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</html>