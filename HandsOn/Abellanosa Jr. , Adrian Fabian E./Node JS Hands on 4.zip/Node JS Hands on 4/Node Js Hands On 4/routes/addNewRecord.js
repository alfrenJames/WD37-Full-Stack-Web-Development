const express = require('express');
const data = require('../fakeDb/data');
const addNewRecord= express();
const booksController = require('../controllers/bookControllers')

addNewRecord.get('/addNewRecord', booksController.books_addPage);
//add new record
addNewRecord.post('/addNewRecord', booksController.books_add);

module.exports = addNewRecord;