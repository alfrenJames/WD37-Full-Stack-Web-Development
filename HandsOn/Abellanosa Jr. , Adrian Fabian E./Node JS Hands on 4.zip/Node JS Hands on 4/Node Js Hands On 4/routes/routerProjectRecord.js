const express = require('express');
const data = require('../fakeDb/data');
const projectRecord = express.Router();
const booksController = require('../controllers/bookControllers')


//get data 
projectRecord.get('/records',booksController.books_index);

//get by id 
projectRecord.get('/records/:id', booksController.books_find);
  

//update record by id
projectRecord.get('/update/:id', booksController.books_update);

projectRecord.put('/update/:id', booksController.books_toUpdate);
   

//delete record by ID
projectRecord.delete('/:id', booksController.books_delete);



module.exports = projectRecord;
