const express = require('express');
const routerApi = express();
const axios = require('axios');

//localhost:8080/getAll
routerApi.get('/getAll', (req, res)=>{
    axios.get('http://localhost:3000/EmpRecords')
         .then(response =>{
            const records = response.data
            res.status(202).json(records);
            console.log('Get all Record')
         })
         .catch(error => {
            console.log(error);
            res.status(500).json({message: "bad request"})
         })
});

//get by ID
routerApi.get('getById/:id', (req, res)=>{
    const id = req.params.id;
    axios.get(`http://localhost:3000/EmpRecords/${id}`)
         .then(response =>{
           const record = response.data
           res.status(202).json(record);
           console.log(`Was able to get ID: ${id}`)
           console.log(id);
         })
         .catch(error => {
            console.log(error);
            res.status(500).json({message: "bad request"})
         })
});

//post new record
routerApi.post('/addNewRecord', (req, res)=>{
    let body = req.body;
    axios.post('http://localhost:3000/EmpRecords', body)
         .then(response =>{
            res.status(202).send('New Record Added');
            console.log('Added new Record')
         })
         .catch(error => {
            console.log(error);
            res.status(500).json({message: "bad request"})
         })
});

//update record
routerApi.put('/update/:id', (req, res)=>{
    const id = req.params.id;
    let body = req.body;
    let param = req.query
    axios.put(`http://localhost:3000/EmpRecords/${id}`, body)
         .then(response =>{
            res.status(202).send(`Record id:${id} has been updated`);
            console.log('update record success')
         })
         .catch(error => {
            console.log(error, 'no record updated');
            res.status(500).json({message: "bad request"})
         })
});

//get by ID
routerApi.delete('/deleteRecord/:id', (req, res)=>{
    const id = req.params.id;
    axios.delete(`http://localhost:3000/EmpRecords/${id}`)
         .then(response =>{
           const record = response.data
           res.status(202).send(`id ${id} has been deleted`);
           console.log(`Was able to delete ID: ${id}`)
           console.log(id);
         })
         .catch(error => {
            console.log(error, 'no record for such ID found');
            res.status(500).json({message: "bad request"})
         })
});

module.exports = routerApi;