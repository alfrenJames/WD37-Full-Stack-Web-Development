import React from 'react'
// import Header from './components/Header'
import RandomUser from '../components/RamdomUser'
import RandomAge from '../components/RamdomAge'
import { useState } from 'react'

const Main = () => {
  //calling RandomUser
  const[userName,setName] = useState('No user yet');
  const randomName = () => {
    setName(RandomUser());
    };  
  //Calling RandomAge
  const [userAge,setAge] = useState(0);
  const randomAge = () => {
    setAge(RandomAge());
  };
  //calling both
  const randomNameAndAge = () => {
    randomName();
    randomAge();
  }
  //Calling Header to change theme
  // const [colorTheme,setTheme] = useState('');
  // const changeTheme = () => {
  // setTheme(Header());
  // };
  return (
    <main className='App-Main'>
    <h1>This is main</h1>
      {userName}<br/>{userAge}
      <div className="mt-1 border border-1"></div>
        <button className="my-2" onClick={randomName}>Generate Random name</button>
        <button className="my-2" onClick={randomAge}>Generate Random age</button>
        <button className="my-2" onClick={randomNameAndAge}>Generate Random name and Age</button>
    </main>
  )
}

export default Main