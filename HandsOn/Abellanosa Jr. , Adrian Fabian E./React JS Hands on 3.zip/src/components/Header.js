import React from 'react'
import { useState } from 'react';
import Main from '../../src/App.css'

const Header = () => {
  //useState to difine colors
const [color,setColor] = useState('white')

//useState to difine textColor
const [textColor, setTextColor] = useState('black')
const headerStyle = {
    backgroundColor: color,
    color: textColor
};
//function to change the theme to dark
const changeToLight = ()=>{
  setColor('white');
  setTextColor('black');
}
//function to change the theme to dark
const changeToDark = ()=>{
  setColor('black');
  setTextColor('white');
}

const MainLight = () => {
  const element = document.querySelector('.App-Main');
  element.style.backgroundColor = 'white';
  element.style.color = 'black'
}
const MainDark = () => {
  const element = document.querySelector('.App-Main');
  element.style.backgroundColor = 'black';
  element.style.color = 'white'
}

const whiteTheme = () => {
  changeToLight();
  MainLight();
}
  const darkTheme = () => {
    changeToDark();
    MainDark();
  }

  return (
    <header className="App-header" style={headerStyle}>{textColor}
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled">Disabled</a>
        </li>
      </ul>
    </div>
    <button className='btn btn-light m-2 border border-2' onClick={whiteTheme}></button>
    <button className='btn btn-dark m-2' onClick={darkTheme}></button>
  </div>
</nav>
</header>
  )
}
export default Header