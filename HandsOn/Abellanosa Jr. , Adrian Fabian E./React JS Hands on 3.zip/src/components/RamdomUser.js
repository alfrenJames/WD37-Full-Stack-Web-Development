import React from 'react'

const RamdomUser = () => {
        const randomUser = ['User 1','User 2','User 3','User 4','User 5']
        const index = Math.floor(Math.random() * 5);
      return randomUser[index];
    }

export default RamdomUser