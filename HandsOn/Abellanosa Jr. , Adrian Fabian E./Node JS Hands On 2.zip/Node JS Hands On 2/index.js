const express = require('express');
const app = express();
const getProjectRecord = require('./routes/routerProjectRecord');


//middleware
app.use(express.json());
app.use(express.urlencoded({extended:true}));



//routes
// app.use('/records', (req, res)=>{
//     res.send('Server 8001 connected');  
// });
app.use('/records', getProjectRecord);


//server conn check
let port = 8001;
app.listen(port,()=>{
    console.log(`connection successfull with port: ${port}`);
});