const express = require('express');
const projectRecord = express.Router();

let data =[
    { id: 1, title: 'Create a project',  order: 1, completed: true, author: 'Diego Laura' },
    { id: 2, title: 'Take a cofféé',     order: 2, completed: true, author: 'Laong-Laan' },
    { id: 3, title: 'Write new article', order: 3, completed: true, author: 'Agap-ito Bagumbayan' },
    { id: 4, title: 'Walk toward home', order: 4, completed: false, author: 'Taga-Ilog' },
    { id: 5, title: 'Have some dinner', order: 5, completed: false, author: 'Dimas-Ilaw' }
];

//get data
projectRecord.get('/projectRecord', (req, res)=>{
    res.status(222).send(data);
    console.log('getting all emp records is successful!')
});

//get by id
projectRecord.get('/projectRecord/:id', (req, res)=>{
    let checkID = data.find((projID)=>{
        return projID.id === parseInt(req.params.id)
    });
    if (checkID){
        res.status(200).json(checkID);
        console.log('Id exist')
    }else{
        res.status(400).send('Id does not exist');
        console.log('Id does not exist');
    }
});

//post new record
projectRecord.post('/postNewRecord',(req, res)=>{
    let body = req.body;
    res.status(214).send('Added new record');
    data.push(body);
    console.log('added new record:' +body);
});

//update record by id
projectRecord.put('/updateRecordById/:id',(req, res)=>{
    let paramId = +req.params.id;
    let body = req.body;
    let index = data.findIndex((dat)=>dat.id===paramId);
        if(index>=0){
            let updateData = {id:paramId,...body};
            data[index] = updateData;
            res.status(200).json(updateData);
            console.log(`id: ${paramId} was updated`);
        }else{
            res.status(404).send('Id does not exist!')
        }
});
   

//delete record by ID
projectRecord.delete('/deleteRecordById/:id',(req, res)=>{
    let paramId = +req.params.id;
    let index = data.findIndex((dat) => dat.id === paramId);
        if(index>=0){
            data.splice(index,1);
            res.status(201).json(data);
            console.log(`Id: ${paramId} successfuly deleted`);
        }else{
            res.status(404).send('Id does not exist!');

        }
});


module.exports = projectRecord;