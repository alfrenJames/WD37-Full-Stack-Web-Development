const routerRegistration = require('express').Router();

const registrationControllers = require('../controllers/registrationControllers');

//add new user
// routerRegistration.post('/register',registrationController);
routerRegistration.get('/register', (req, res)=>{
    res.render('register', {title:'Register', message: false});
});
routerRegistration.post('/register', registrationControllers);

module.exports = routerRegistration;