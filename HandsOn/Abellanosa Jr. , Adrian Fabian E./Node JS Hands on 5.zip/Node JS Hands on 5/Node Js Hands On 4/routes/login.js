const loginRouter = require('express').Router();
const loginControllers = require('../controllers/loginControllers');


loginRouter.get('/login', (req, res)=>{
    res.render('login', {title:'Login' ,message: false});
});
loginRouter.post('/login', loginControllers);

module.exports = loginRouter;