const express = require('express');
const homeRouter= express();

homeRouter.get('/home', (req, res)=>{
    res.render('home');
    res.render('home', {test:'EJS is working and Waving 🙌', message: false });
});

module.exports = homeRouter;