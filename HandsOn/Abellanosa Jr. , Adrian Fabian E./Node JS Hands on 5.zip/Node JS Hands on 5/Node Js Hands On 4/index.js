const express = require('express');
const app = express();
const getProjectRecord = require('./routes/routerProjectRecord');
const homeRouter = require('./routes/home');
const addNewRecord = require('./routes/addNewRecord');
const routerGallery = require('./routes/gallery');
const loginRouter = require('./routes/login');
const routerRegistration = require('./routes/register');
const methodOverride = require('method-override');
const mongoose = require('mongoose');
const dotEnv = require('dotenv');


//static File
app.use(express.static('public'));
app.use('/css', express.static(__dirname+'public/css'));

//middleware
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(methodOverride('_method'));
dotEnv.config();


app.use((req,res, next) =>{
    // console.log("request has been made");
    console.log("host", req.hostname);
    console.log("path", req.path);
    // console.log("method", req.method);
    next();
})

//routes
app.use('/', homeRouter);
app.use('/', getProjectRecord);
app.use('/', addNewRecord);
app.use('/', routerGallery);
app.use('/', loginRouter);
app.use('/', routerRegistration);


//setup views
app.set('views', './views');
app.set('view engine', 'ejs');

var port = 80;
app.listen(port, ()=>{
    console.log(`server is now running in port:${port}`)
});
//mongooDB conn
mongoose.connect(process.env.DB_CONNECT, ()=>{
    console.log('database connection is working!')
});
