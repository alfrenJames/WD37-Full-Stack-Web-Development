const {schemaRegister} = require('./validation');
const bcrypt = require('bcryptjs');
const User = require('../models/user');

module.exports =  async(req, res)=>{
    //validate registration
    const validateData = schemaRegister.validate(req.body)
   if(validateData.error) return res.status(400).send(validateData.error.details[0].message);
    //check if user name exist
    const userName = await User.findOne({name: req.body.name}); 
    if(userName) return res.status(400).render('register',{title: 'Register', message:'Name already exist'});
    //check if email exist
    const userEmail = await User.findOne({email:req.body.email});
    if(userEmail) return res.status(400).render('register',{title: 'Register', message:'Email already exist'}); 
    //Encrypt Password
    const salt = await bcrypt.genSalt(10);
    const hashedPass = await bcrypt.hash(req.body.password, salt);
    const newUser = new User({
        name: req.body.name,
        password: hashedPass,
        email: req.body.email
    });
    try {
        const savedUser = await newUser.save();
        res.status(201).send(savedUser);
         console.log('New User Added!');
    } catch (error) {
        res.status(500).send(error.message);
    }
}