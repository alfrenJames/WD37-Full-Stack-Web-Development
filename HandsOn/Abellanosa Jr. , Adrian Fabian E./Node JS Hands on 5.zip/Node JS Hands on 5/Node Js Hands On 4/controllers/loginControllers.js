const User = require('../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const {schemaLogin} = require('./validation');

const userLogin = async(req, res)=>{
    //validate body
    const validateData = schemaLogin.validate(req.body)
    if(validateData.error) return res.status(400).send(validateData.error.details[0].message);
      //check if existing email
      const checkEmail = await User.findOne({email: req.body.email})
     if(!checkEmail) return res.status(400).render('login',{title: 'Login', message:'Email or password is incorrect'});
       //validate password
       const userPass = await bcrypt.compare(req.body.password, checkEmail.password)
    if(!userPass) return res.status(400).render('login',{title: 'Login', message: 'Email or Password is incorrect'});
    //produce token
    const token = jwt.sign({name: User.name}, process.env.TOKEN_SECRET);

  
    
    res.header('token', token).render('home',{title: 'Login', message:`successfully log-in as: ${checkEmail.name}`});
    console.log("Login Success!");
 }


module.exports = userLogin;

