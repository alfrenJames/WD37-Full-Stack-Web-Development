const Joi = require('joi');
const schemaLogin = Joi.object({
    password: Joi.string().min(6).required(),
    email: Joi.string().min(6).email().required()
});

const schemaRegister = Joi.object({
    name: Joi.string().min(6).required(),
    password: Joi.string().min(6).required(),
    email: Joi.string().min(6).email().required()
});
module.exports = {schemaLogin, schemaRegister}