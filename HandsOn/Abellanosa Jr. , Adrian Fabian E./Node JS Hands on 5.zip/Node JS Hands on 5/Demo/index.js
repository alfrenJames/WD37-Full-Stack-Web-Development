//imported Dependencies
const express = require('express');
const routerApi = require('./routes/api');
const homeRouter = require('./routes/home');
const app = express();


//StaticFiles
app.use(express.static('public'));
app.use('/style', express.static(__dirname + 'public/css'));
app.use('/js', express.static(__dirname + 'public/js'));
app.use('/img', express.static(__dirname + 'public/img'));

//middleWare
app.use(express.json());
app.use(express.urlencoded({extended:true}));

//routes
app.use('/home', homeRouter);
app.use('/', routerApi);

//views
app.set('views', './views');
app.set('view engine', 'ejs');

const port = 8080;
app.listen(port,()=>{
    console.log('Conn success to port:'+port);
});