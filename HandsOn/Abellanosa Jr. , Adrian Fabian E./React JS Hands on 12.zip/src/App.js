import Register from './components/Register'
import './App.css';

function App() {
  return (
    <div className="App">
      <Register/>
    </div>
  );
}

export default App;
