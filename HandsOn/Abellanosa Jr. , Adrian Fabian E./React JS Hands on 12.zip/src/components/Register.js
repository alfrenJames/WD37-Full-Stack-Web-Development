import { useState } from "react";

const Register = () => {
//state of error
const [errorName, setErrName] = useState('')
const [errorEmail, setErrEmail] = useState('')
const [errorPass, setErrPass] = useState('')
const [valid, setValid] = useState(false)

//validate form Function
const validateForm = (event) => {
    event.preventDefault();
    const {name, value} = event.target;
    const emailValid = RegExp(/^\w+([\.-]?\w+)*@\w([\.-]?\w+)*(\.\w{2,3})+$/);
    switch (name) {
        case 'name':
            if (value.length <= 4) {
                //add error message if length of name does not meet
                setErrName('Full name must be 5 character long!')
                setValid(false)
                //checking value if was able to get by onchange event, err capture and valid
                console.log(value, errorName, valid)
            } else {
                //set no error message if name length meet
                setErrName('')
                //checking value if was able to get by onchang event, err capture and valid
                console.log(value, errorName, valid)
            }
            break;
        case 'email':
            if (emailValid.test(value) === false){
                setErrEmail('Email is Invalid');
                setValid(false)
            }else {
                setErrEmail('')
            }
            break;
        case 'password':
            if (value.length < 8) {
                setErrPass('Password must be 8 character long!')
                setValid(false)
            } else {
                setErrPass('')
            }
            break;
        default:
            break;
    }
    //if no error valid state will be true
    if(errorName==='' && errorEmail==='' &&errorPass===''){
        setValid(true)
     }
    }

    function onFormSubmit(){
        console.log(valid);
        if (!valid){
            alert("Some inputField need to be valid!");
        } else {
            alert("Valid Form")
        }
    }

    return (
        <div className="container">
            <div className="cart mt-5">
                <form className="card-body" onSubmit={onFormSubmit}>
                    <div className="form-group mb-3">
                        <label className="mb-2">
                            <strong>Name</strong>
                        </label>
                        <input 
                            required
                            type="text"
                            name="name"
                            onChange={validateForm}
                            className={
                                errorName.length > 0
                                    ? "is-invalid form-control"
                                    : "form-control"
                            }
                        />
                        {errorName.length > 0 && (
                            <span className="invalid-feedback">{errorName}</span>
                        )}
                    </div>
                    <div className="form-group mb-3">
                        <label className="mb-2">
                            <strong>Email</strong>
                        </label>
                        <input
                            required
                            type="text"
                            name="email"
                            onChange={validateForm}
                            className={
                                errorEmail.length > 0
                                    ? "is-invalid form-control"
                                    : "form-control"
                            }
                        />
                        {errorEmail.length > 0 && (
                            <span className="invalid-feedback">{errorEmail}</span>
                        )}
                </div>
                    <div className="form-group mb-3">
                        <label className="mb-2">
                            <strong>Password</strong>
                        </label>
                        <input 
                        required
                        type="password"
                        name="password"
                        onChange={validateForm}
                        className={
                            errorPass.length > 0
                                ? "is-invalid form-control"
                                : "form-control"
                        }
                        />
                        {errorPass.length > 0 && (
                            <span className="invalid-feedack">{errorPass}</span>
                        )}
                    </div>
                            <button type = "submit" class="btn btn-primary">
                                Submit
                            </button>
                </form>
            </div>
        </div>
    );
}

export default Register