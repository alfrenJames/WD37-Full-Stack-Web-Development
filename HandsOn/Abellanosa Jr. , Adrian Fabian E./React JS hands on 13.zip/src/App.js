import RandomUser from './components/RandomUser'
import './App.css';

function App() {
  return (
    <div className="App">
      <RandomUser/>
    </div>
  );
}

export default App;
