import { useState, useEffect } from 'react'

const RandomUser = () => {
  const url = 'https://random-data-api.com/api/v2/users'
  const [user, setUser] = useState({})
  const getRandomUser = async()=>{
    try {
      const res = await fetch(url, {mode: 'cors'})
      const randomUser = await res.json()
      setUser(randomUser)
      console.log(user.picture.large)
    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    getRandomUser()
  },[])
  const {avatar, first_name, last_name, date_of_birth} = user
  return (
    <main>
    <div className='container bg-primary text-black'>
       <h1>Get Random User</h1>
       <button onClick={getRandomUser}>Get User</button>
       <hr />
       <section>
       <img src={avatar} alt='alt avatar' />
       <h1>🙍Name: {first_name} {last_name}</h1>
       <h2>🏥Date of Birth: {date_of_birth}</h2>
       </section>
    </div>
    </main>
  )
}


    //Sir's Code

// const RandomUser = () => {
//   const url = 'https://randomuser.me/api/'
//   const [user, setUser] = useState({})
//   const getRandomUser = async()=>{
//     try {
//       const res = await fetch(url, {mode: 'cors'})
//       const randomUser = await res.json()
//       setUser(randomUser.results[0])
//       console.log(user.picture.large)
//     } catch (error) {
//       console.log(error)
//     }
//   }
//   useEffect(() => {
//     getRandomUser()
//   },[])
//   const {picture, name, dob} = user
//   return (
//     <main>
//     <div className='container bg-primary'>
//        <h1>Get Random User</h1>
//        <button onClick={getRandomUser}>Get User</button>
//        <hr />
//        <section>
//        <img src={picture.large} alt={name.title + name.first} />
//        <h1>🙍‍♂️Name: {name.title} {name.first} {name.last}</h1>
//        <h2>🏥Date of Birth: {dob.date} Age: {dob.age}</h2>
//        </section>
//     </div>
//     </main>
//   )
// }

export default RandomUser