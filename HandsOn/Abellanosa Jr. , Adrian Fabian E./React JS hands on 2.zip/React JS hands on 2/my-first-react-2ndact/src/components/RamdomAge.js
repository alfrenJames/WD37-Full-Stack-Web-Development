import React from 'react'

const RamdomAge = () => {
    const randomAge = [16,17,21,19,20]
    const index = Math.floor(Math.random() * 5);
    if (randomAge[index] >= 18){
        return randomAge[index] + ': an Adult!';
    }else{
        return randomAge[index] + ': Too Young!';
    }

}
export default RamdomAge