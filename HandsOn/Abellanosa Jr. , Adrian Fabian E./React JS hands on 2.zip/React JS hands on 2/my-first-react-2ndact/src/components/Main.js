import React from 'react'
import RandomUser from '../components/RamdomUser'
import RandomAge from '../components/RamdomAge'

const Main = () => {
  return (
    <main className='App-Main'>
    <h1>This is main</h1>
        <RandomUser></RandomUser>
        <br />
        <RandomAge></RandomAge>
    </main>
  )
}

export default Main