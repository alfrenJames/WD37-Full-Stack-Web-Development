import LoginControl from './components/LoginControl';
import './App.css';

function App() {
  return (
    <LoginControl/>
  );
}

export default App;
