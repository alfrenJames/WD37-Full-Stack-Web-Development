import React from 'react'
import { TabTitle } from '../../utilities/Title'

export default function NotFound() {
  TabTitle('Page Not Found');
  return (
    <div>NotFound</div>
  )
}
