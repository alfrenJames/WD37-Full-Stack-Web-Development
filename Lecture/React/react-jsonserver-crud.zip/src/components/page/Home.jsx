import React from 'react'
import { TabTitle } from '../../utilities/Title'
import './style.css';
import NavBar from '../semantics/NavBar'
export default function Home() {
    TabTitle('Home Page');
    return ( 
      <div className = 'bg-primary'> 
      <NavBar></NavBar>
      Home 
      </div>
    )
}