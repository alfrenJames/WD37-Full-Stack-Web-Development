import React, {useState, useEffect} from 'react';
import { Link } from "react-router-dom";
export default function NavBar() {
  return (
    <nav className='navbar navbar-light bg-light container'>
        <div className='container-fluid'>
            <Link to={"/HOME"} className="navbar-brand h1">
                <i className='fa fa-home'></i>HOME  
            </Link>
            <Link to={"/all"} className="navbar-toggler text-decoration-none">
                <i className='fa fa-user'></i>All User
            </Link>
            <Link to={"/add"} className="navbar-toggler text-decoration-none">
                <i className='fa fa-plus'></i>Add User
            </Link>
        </div>
    </nav>
  )
}
