//dynamic change of titles
export const TabTitle = (newTitle) => {
    return (document.title = newTitle);
}