const express = require('express');
const dataRecord = require('../fakeDb/dataRecord');
const routerRecord = express.Router();

//get all record Testing of Api
//localhost:80/getAllRecord
routerRecord.get('/getAllRecord', (req, res)=>{
     res.status(200).json(dataRecord);
    console.log('Get All Records');
});


//get record by id
//localhost:80/getRecord/id
routerRecord.get('/getRecord/:id', (req, res)=>{
    let check = dataRecord.find((items)=>{
        return items.id === parseInt(req.params.id)
    });
    //verfiy if id exist
    if(check){
        res.status(201).json(check);
        console.log('Record by ID Found');
    }else{
        res.status(400).send('ID Does Not Exist')
        console.log('Record ID Not Found');
    }
});
//add new Record
//localhost:80/postNewRecord
routerRecord.post('/postNewRecord', (req, res)=>{
    dataRecord.push(req.body);
    res.status(201).send('add new Record');
    console.log("added new record",req.body);
});

//update new record
//localhost:80/putRecord/id
routerRecord.put('/putRecord/:id', (req, res)=>{
     //put the query into a variable
     let body = req.body;
     //Check if there is a match in the pseudo database
     let check = dataRecord.find((item)=>{
         return item.id === parseInt(body.id);
     });
     //If the checking returned true update data, else display an error 
     if(check){
         //Find index of specific object using findIndex method.    
         let objIndex = dataRecord.findIndex((obj => obj.id == body.id));
         //Update pseudo database.
         dataRecord[objIndex] = body;
         //return status Created and will send a notification
         res.status(200).send('Data Modified.')
     } else {
         //return status Not found and will send a notification
         res.status(404).send('Data not found.');
     }

});

//delete Record
//localhost:80/deleteRecord/id
routerRecord.delete('/deleteRecord/:id', (req, res)=>{
     //put the query into a variable
     let param = req.params;
     //Check if there is a match in the pseudo database
     let check = dataRecord.find((item)=>{
         return item.id === parseInt(param.id);
     });
     //If the checking returned true delete data, else display an error 
     if(check){
         //Find index of specific object using findIndex method.    
         let objIndex = dataRecord.findIndex((obj => obj.id == param.id));
         //Delete pseudo database entry.
         dataRecord.splice(objIndex, 1);
         //return status OK and will send a notification
         res.status(200).send('Data Deleted.');
         console.log('Deleted Record With ID:',param);
     } else {
         //return status Not found and will send a notification
         res.status(404).send('Data not found.');
         console.log('Try to delete but no record found');
     }
});
module.exports = routerRecord;

