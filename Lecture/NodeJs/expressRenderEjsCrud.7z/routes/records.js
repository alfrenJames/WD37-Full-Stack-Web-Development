const express = require('express');
const { redirect } = require('express/lib/response');
const dataRecord = require('../fakeDb/dataRecord');
const routerRecord = express.Router();
//get all records and rendered 
routerRecord.get('/', (req, res)=>{
    //res.status(200).json(dataRecord);
   res.render('records', {data: dataRecord});
    console.log('Get All Records');
});

//add new record
routerRecord.post('/', (req, res)=>{
    let body = req.body;
    dataRecord.push(body);
    console.log("added new record",body);
    res.redirect('records');
});

//get by id
// routerRecord.get('/:id', (req, res)=>{
//     let check = dataRecord.find((items)=>{
//         return items.id === parseInt(req.params.id)
//     });
//     //verfiy if id exist
//     if(check){
//         // res.status(201).json(check);
//         // console.log('Record by ID Found');
//         res.redirect('view');
//     }else{
//         res.status(400).send('ID Does Not Exist');
//         console.log('Record ID Not Found');
//         //res.redirect('pageNotFound')
//     }
//     // res.redirect('about');
// });

routerRecord.get('/:id', (req,res)=>{
    let check = dataRecord.find((items)=>{
        return items.id == parseInt(req.params.id)
    });
    if(check){
                res.render('view', {records: check});
            }else{
                res.status(400).send('ID Does Not Exist');
                console.log('Record ID Not Found');
            }
});


module.exports = routerRecord;