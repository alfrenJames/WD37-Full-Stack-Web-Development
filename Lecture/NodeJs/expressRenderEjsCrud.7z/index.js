//import
const express = require('express');
const homeRouter = require('./routes/home');
const aboutRouter = require('./routes/about');
const galleryRouter = require('./routes/gallery');
const routerApiTest = require('./routes/restApi');
const routerRecord = require('./routes/records');
const app = express();

//static file
app.use(express.static('public'));
app.use('/css', express.static(__dirname+'public/css'));
app.use('/js', express.static(__dirname+'public/js'));
app.use('/img', express.static(__dirname+'public/img'));

//middleware
app.use(express.json());
app.use(express.urlencoded({extended: true}));
//routes
app.use('/',homeRouter);
app.use('/home',homeRouter);
app.use('/',aboutRouter);
app.use('/',galleryRouter);
app.use('/records',routerRecord);
app.use('/',routerApiTest);


//setup views
app.set('views', './views');
app.set('view engine', 'ejs');
//check connection of the server
const port = 80;
app.listen(port, ()=>{
    console.log(`The Server is now Running on Port: ${port}`);
});