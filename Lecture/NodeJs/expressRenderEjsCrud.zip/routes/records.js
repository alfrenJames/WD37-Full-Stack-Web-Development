const express = require('express');
const dataRecord = require('../fakeDb/dataRecord');
const routerRecord = express.Router();

routerRecord.get('/records', (req, res)=>{
    //res.status(200).json(dataRecord);
   res.render('records', {data: dataRecord});
    console.log('Get All Records');
});

module.exports = routerRecord;