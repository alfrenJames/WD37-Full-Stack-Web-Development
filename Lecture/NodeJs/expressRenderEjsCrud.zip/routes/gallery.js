const express = require('express');
const galleryRouter = express.Router();
galleryRouter.get('/gallery',(req, res)=>{
    res.render('gallery');
   });
module.exports = galleryRouter;