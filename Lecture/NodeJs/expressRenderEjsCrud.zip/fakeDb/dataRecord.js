//array of object 
let dataRecord = [
    {id: 1, name: "Jose", pic:'https://th.bing.com/th/id/OIP.YUdOkbR1zQZoQdmeWFAeNAHaI4?pid=ImgDet&rs=1', salary: 30000, position: 'Web Dev', company: 'microsoft'},
    {id: 2, name:"Erika", pic:'https://th.bing.com/th/id/OIP.YUdOkbR1zQZoQdmeWFAeNAHaI4?pid=ImgDet&rs=1', salary: 30000, position: 'Web Dev', company: 'microsoft'},
    {id: 3, name: "JP", pic:'https://th.bing.com/th/id/OIP.YUdOkbR1zQZoQdmeWFAeNAHaI4?pid=ImgDet&rs=1', salary: 30000, position: 'Web Dev', company: 'microsoft'},
    {id: 4, name: "Ben", pic:'https://th.bing.com/th/id/OIP.YUdOkbR1zQZoQdmeWFAeNAHaI4?pid=ImgDet&rs=1', salary: 30000, position: 'Web Dev', company: 'microsoft'}
];
module.exports = dataRecord;