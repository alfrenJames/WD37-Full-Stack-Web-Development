const express = require('express');
const routerHome = express.Router();

routerHome.get('/', (req, res) => {
    res.render('home', { test: 'Ejs is working and waving 👋' });
});
module.exports = routerHome;