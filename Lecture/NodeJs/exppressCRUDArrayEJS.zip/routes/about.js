const express = require('express');
const routerAbout = express.Router();

routerAbout.get('/', (req, res) => {
    res.render('about', { test: 'Ejs is working and waving 👋' });
});
module.exports = routerAbout;