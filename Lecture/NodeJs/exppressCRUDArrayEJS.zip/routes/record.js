const express = require('express');
const routerRecord = express.Router();

let dataRecord = [
    { id: 1, imgsrc: 'https://images.pexels.com/photos/457882/pexels-photo-457882.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', name: 'San Francisco Beach' },
    { id: 2, imgsrc: 'https://images.pexels.com/photos/13291078/pexels-photo-13291078.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', name: 'New York Beach' },
    { id: 3, imgsrc: 'https://images.pexels.com/photos/13262088/pexels-photo-13262088.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', name: 'Seattle Beach' },
    { id: 4, imgsrc: 'https://images.pexels.com/photos/13077046/pexels-photo-13077046.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', name: 'Los Angeles Beach' },
    { id: 5, imgsrc: 'https://images.pexels.com/photos/12913419/pexels-photo-12913419.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', name: 'Chicago Beach' },
];

routerRecord.get('/', (req, res) => {
    res.render('record', { data: dataRecord });
    console.log(dataRecord);
});

routerRecord.get('/search/:name', (req, res) => {
    let check = dataRecord.find((item) => {
        return item.name === req.params.name;
    });
    if (check) {
        document.getElementById('beaches').value = dataRecord;
    } else {
        res.status(404).send('ID not found!');
    }
});



routerRecord.post('', (req, res) => {
    let body = req.body;
    dataRecord.push(body);
    console.log(dataRecord);
    res.redirect('/record');
});

routerRecord.get('/view/:id', (req, res) => {
    let check = dataRecord.find((item) => {
        return parseInt(item.id) === parseInt(req.params.id)
    });
    if (check) {
        res.render('view', { records: check });
    } else {
        res.status(404).send('ID not found!');
    }
});

routerRecord.get('/update/:id', (req, res) => {
    let check = dataRecord.find((item) => {
        return parseInt(item.id) === parseInt(req.params.id)
    });
    if (check) {
        res.render('edit', { records: check });
    } else {
        res.status(404).send('ID not found!');
    }
});

routerRecord.put('/update/:id', (req, res) => {
    let id = +req.params.id;
    let body = req.body;
    let index = dataRecord.findIndex((df) => parseInt(df.id) === parseInt(id));

    if (index >= 0) {
        let updateData = { id: id, ...body };
        dataRecord[index] = updateData;
        res.redirect('/record');
    } else {
        res.status(404).send('Id does not exist');
    }

});

routerRecord.delete('/:id', (req, res) => {
    let id = +req.params.id;
    let index = dataRecord.findIndex((df) => parseInt(df.id) === parseInt(id));
    if (index >= 0) {
        dataRecord.splice(index, 1);
        res.redirect('/record');
    } else {
        res.status(404).send('ID not found');
    }
});

module.exports = routerRecord;