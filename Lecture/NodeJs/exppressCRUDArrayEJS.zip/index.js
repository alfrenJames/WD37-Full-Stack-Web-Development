//import
const express = require('express');
const methodOverride = require('method-override');
const bodyParser = require('body-parser');
const routerHome = require('./routes/home');
const routerAbout = require('./routes/about');
const routerGallery = require('./routes/gallery');
const routerRecord = require('./routes/record');
const app = express();

//staticfiles
app.use(methodOverride('_method'));
app.use(express.static('public'));
app.use('/style', express.static(__dirname + 'public/css'));
app.use('/js', express.static(__dirname + 'public/js'));
app.use('/img', express.static(__dirname + 'public/img'));


//middleware
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//routes
app.use('/home', routerHome);
app.use('/record', routerRecord);
app.use('/about', routerAbout);
app.use('/gallery', routerGallery);

//views
app.set('views', './views');
app.set('view engine', 'ejs');


const port = 8080;
app.listen(port, () => {
    console.log(`The server is now running in port: ${port}`);
});